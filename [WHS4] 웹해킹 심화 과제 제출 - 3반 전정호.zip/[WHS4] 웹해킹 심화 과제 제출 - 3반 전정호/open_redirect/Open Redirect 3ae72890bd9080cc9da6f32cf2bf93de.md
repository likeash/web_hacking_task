# Open Redirect

![image.png](image.png)

위와 같이 특정 엔드포인트로 라디이렉트를 수행한다. 타 도메인으로 리다이렉트 시 flag를 획득할 수 있다.

![image.png](image%201.png)

위 사진은 파라미터 검증 로직이다. 리다이렉트 되는 주소에 /으로 시작하거나, localhost가 존재한다면 안전한다고 판단한다. 따라서, 

```
http://edu.arang.kr:9108/go?next=naver.com/localhost
```

와 같이 작성하면 검증 로직을 우회할 수 있다.

`flag{531256e0cb5245ea3517}`